<?php
\Magento\Framework\Component\ComponentRegistrar::register(
\Magento\Framework\Component\ComponentRegistrar::MODULE,
'GianlucaScoponi_CustomAttributeTab',
__DIR__
);