<?php

/**
 * @author Gianluca Scoponi
 * 
 * @package GianlucaScoponi_CustomAttributeTab
 */

namespace GianlucaScoponi\CustomAttributeTab\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class RemoveBlockCustomTab implements ObserverInterface
{
    protected $_registry;

    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Request\Http $request
    )
    {        
        $this->_registry = $registry;
        $this->_request = $request;
    }

    public function execute(Observer $observer)
    {
        if ($this->_request->getFullActionName() == 'catalog_product_view') {
            $product = $this->_registry->registry('current_product');
            //$attrVal = $product->getAttributeText('test');
            $attrVal = $product->getData('attr1');
            if(!isset($attrVal) || trim($attrVal) === ''){
                $layout = $observer->getLayout();
                $layout->unsetElement('tab.attr1');
            }
        }
		
		if ($this->_request->getFullActionName() == 'catalog_product_view') {
            $product = $this->_registry->registry('current_product');
            //$attrVal = $product->getAttributeText('test');
            $attrVal = $product->getData('attr2');
            if(!isset($attrVal) || trim($attrVal) === ''){
                $layout = $observer->getLayout();
                $layout->unsetElement('tab.attr2');
            }
        }
		
		
		if ($this->_request->getFullActionName() == 'catalog_product_view') {
            $product = $this->_registry->registry('current_product');
            //$attrVal = $product->getAttributeText('test');
            $attrVal = $product->getData('attr3');
            if(!isset($attrVal) || trim($attrVal) === ''){
                $layout = $observer->getLayout();
                $layout->unsetElement('tab.attr3');
            }
        }
		
		
		
    }
	
}